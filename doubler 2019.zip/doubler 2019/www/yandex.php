<?
define('SCRIPT_BY_SIRGOFFAN',dirname(__FILE__));
require_once('core/classes/safemysql.php');
require_once('core/config.php');
require_once('core/classes/competition.php');
require_once('core/functions.php');

if (!empty($_POST['label']) and $_POST['codepro']=="false" and $_POST['withdraw_amount']>= 10)
{

	$paydate = explode(".", $_POST['label']);
    $id=intval($paydate[0]);
	$sum=number_format($_POST['withdraw_amount'], 2, '.', ''); 
	$arHash = array($_POST['notification_type'],
			$_POST['operation_id'],
			$_POST['amount'],
			$_POST['currency'],
			$_POST['datetime'],
			$_POST['sender'],
			$_POST['codepro'],
			$y_key,
			$_POST['label']);
	$sign_hash = hash('sha1', implode('&', $arHash));
    $arHash2 = array($id,$y_key,$sum);
	$sign_hash2 = strtoupper(hash('sha1', implode('&', $arHash2)));
	
	
if ($_POST['sha1_hash'] == $sign_hash and $paydate[1]==$sign_hash2)
{

$sql = $pdo->Query("SELECT * FROM db_payeer_insert WHERE id = '{$id}' and status=0 and type=1")->fetch();
if(empty($sql[id])){ exit;}

$pdo->Query("UPDATE db_payeer_insert SET status = '1' WHERE id = '{$id}'");
$id=$sql[user_id];

$competition = new competition($pdo);
$competition->UpdatePoints($id, $sum);
$referer=$db->getOne("SELECT curator FROM `ss_users` WHERE id=?i", $id);
$pdo->Query("UPDATE ss_users SET psum = psum+'$sum' WHERE id = '".$id."'");
$db->query("INSERT INTO deposits (userid, curatorid, summa, unixtime) VALUES(?i,?i,?s,?s)", $id, $referer, $sum, time());	
addpay($id, "Оплата депозита", $sum);

//Затем рефские.
$refererwallet=strtoupper($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i", $referer));
$referersum=$sum*($refpercent/100);
if($referer>0 ){
$pdo->Query("UPDATE ss_users SET cursum = cursum+'$referersum' WHERE id = '".$referer."'");
whithdraw('Выплата партнерских от MORROWS ZONE',$referer,$refererwallet,$referersum);		
addUserStat($referer, "<!--stat--><!--whithdraw--><!--fromreferal-->Выплата", "<!--stat--><!--whithdraw--><!--fromreferal-->Выплата реферальных  (".$referersum." руб.)");
addpay($referer, "Партнерские отчисления", $referersum);
}
}

}
?>