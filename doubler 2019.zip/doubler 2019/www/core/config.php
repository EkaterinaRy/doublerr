<?php
include_once 'security.php';
$host = 'localhost'; //хост базы
$db = 'demo11';
$user = 'demo11';
$pass = '';
$charset = 'UTF8';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$opt = array( PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC );

$pdo = new PDO($dsn, $user, $pass, $opt);
$pdo->exec("set names utf8");


$db = new SafeMySQL(array('user' => $user, 'pass' => $pass, 'db' => $db, 'charset' => 'utf8'));


//Название проекта
$sitename="MORROWS ZONE";
//Описание проекта
$description="Распределение денежного потока MORROWS ZONE";
//Дата старта
$privetstvie='Распределение денежного потока MORROWS ZONE'; //Тупо пишем текстом что нужно, например дату старта, как нравится
//Вкл/выкл капчи (1 - вкл, 0 - выкл)
$use_kapcha=0;
//Режим работы сайта. 1 - сайт работает, 0 - регистрация закрыта
$itworks=1;
//Тип соединения (http или https)
$http_s="https";


//Настройки PAYEER
//ПРИЕМ СРЕДСТВ (мерчант):
$m_shop = '536833397'; //ID магазина в системе Payeer
$m_desc = 'Оплата депозита '.$sitename; //Текст комментария к платежу
$m_key = 'werwr34KIHiuor';
//ВЫПЛАТА (api):
$accountNumber = 'P488'; //Счет, с которого будут происходить выплаты
$apiId = '53'; //ID API
$apiKey = 'lvAq6r5r'; //Секретный ключ API
$m_curr='RUB';


//Настройки Yandex
//ПРИЕМ СРЕДСТВ (мерчант):
$y_wallet = '410012495640645'; //кошелек
$y_key = 'rfb7BD0Smrc4jmcYjZ2pXjeO'; //секретный ключ

//приложение (api):
$appid='AC17A7AD2874FEBA337CA4A5832FCF1AD16D89876DADC6351D963751B65203E9';
$appclient_secret='913DA8AE84886B16CD7AF3462089503DBBC54E0666F024D37BA4CE6DD86B4624FE0801DCA54AE1B23070BD3DC4A6F8CC4001A716E8E917021BC354A3A9AF69D6';
$apptoken='410012495640645.C6CFC9658EC2A654DA90264B2E8BC878CA964500758D4A681F393F442384798F34E5E47DDF960728BCBFD54319C8EFC3944D7566577AD66459DEC0955CB1520E4CAC64930A2714AD8B00BA9BC28885C837D896AFBEE2D133C078865BFD4C3F96234A2E2F14BE3CD53F0E1A573BEDCA26665182422544A0A1611CAAE8D0EE38BE';

//Настройки ADVCASH
//ПРИЕМ СРЕДСТВ (мерчант) SCI: 
$dvamail = '@yandex.ru'; //email акаунта
$dvaname = ''; //название магазина
$advakey = ''; //ключ
//выплаты (мерчант) API: 
$dvapiName = 'morrows_api'; //НАЗВАНИЕ API
$dvaccountEmail = '.@yandex.ru'; //Email пользователя в системе, который владеет API
$adauthenticationToken = ''; //ключ

//Настройки QIwi
//Api
$q_tel = '+'; //номер телефона

//КОШЕЛЕК ПРОЕКТА
$koshelek_admina=''; //Кошелек админа

$adminmail="SUPPORT@MORROWS.ZONE"; //Почта админа
$adminsecretcode=''; //Cекретный код для входа в админку
$adminname=""; //Ник админа
$adminadress="admin"; //Адрес админки (/?page=это_значение)
$admintoken="wgwgwsbvgsd7weshvf7sevgfs"; //Тоукен для некоторых функций в админке (например, для аякса)
$admintoken=md5($admintoken.date("d.m.Y")); //Токен меняется каждый день

//Выплаты по крону? 0 - по крону, 1 - кешем
$nocron=0;

$mindep=200; //Минимальный размер депозита
$maxdep=100000; //Максимальный размер депозита

$refpercent=7; //Реф. процент
$admpercent=10; //Админский процент

$depperiod=24; //выплаты каждые * часов в течении установленного максимального срока
?>