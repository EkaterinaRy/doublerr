<?php
if (!in_array($_SERVER['REMOTE_ADDR'], array('50.7.115.5'))) return;

define('SCRIPT_BY_SIRGOFFAN',dirname(__FILE__));
require_once('core/classes/safemysql.php');
require_once('core/config.php');
require_once('core/classes/competition.php');
require_once('core/functions.php');

$SCI = $advakey;
$Hash = array($_POST['ac_transfer'], //ID-номер операции
	$_POST['ac_start_date'],  //Дата операции
	$_POST['ac_sci_name'],  //Название SCI Продавца
	$_POST['ac_src_wallet'], //Кошелек Покупателя
	$_POST['ac_dest_wallet'], //Кошелек Продавца
	$_POST['ac_order_id'], //ID-номер заказа
	$_POST['ac_amount'], //Сумма платежа
	$_POST['ac_merchant_currency'], //Валюта платежа
	$SCI); //Пароль SCI
	$sign_hash = hash('sha256', implode(":", $Hash));
	//Ниже - проверка на валидность
	if ($_POST['ac_hash'] == $sign_hash)
{

$sql = $pdo->Query("SELECT id,user_id FROM db_payeer_insert WHERE id = '".intval($_POST['ac_order_id'])."' and status=0 and type=3")->fetch();
if(empty($sql[id])){ exit;}
$id=$sql[user_id];
$sum=$_POST['ac_amount']; 
$pdo->Query("UPDATE db_payeer_insert SET status = '1' WHERE id = '".intval($_POST['ac_order_id'])."'");


$competition = new competition($pdo);
$competition->UpdatePoints($id, $sum);

$referer=$db->getOne("SELECT curator FROM `ss_users` WHERE id=?i", $id);

$pdo->Query("UPDATE ss_users SET psum = psum+'$sum' WHERE id = '".$id."'");
$db->query("INSERT INTO deposits (userid, curatorid, summa, unixtime) VALUES(?i,?i,?s,?s)", $id, $referer, $sum, time());	
addpay($id, "Оплата депозита", $sum);
//Затем рефские.
$refererwallet=strtoupper($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i", $referer));
$referersum=$sum*($refpercent/100);
if($referer>0 ){
$pdo->Query("UPDATE ss_users SET cursum = cursum+'$referersum' WHERE id = '".$referer."'");
whithdraw('Выплата партнерских от MORROWS ZONE',$referer,$refererwallet,$referersum);		
addUserStat($referer, "<!--stat--><!--whithdraw--><!--fromreferal-->Выплата", "<!--stat--><!--whithdraw--><!--fromreferal-->Выплата реферальных  (".$referersum." руб.)");
addpay($referer, "Партнерские отчисления", $referersum);
echo 'ok';
}



} else {
echo 'error';
          }

?>