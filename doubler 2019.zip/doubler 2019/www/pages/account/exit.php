<?
if(!defined('SCRIPT_BY_SIRGOFFAN')){
exit();
}
	unset($_SESSION["login"]);
	unset($_SESSION["password"]);
	unset($_SESSION["id"]);
header('Location: /');
exit();
?>
