<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
$_OPTIMIZATION["title"] = "Добавить видео";
?>

<div class="card">
<div class="card-body collapse in">
<div class="card-block">
<div class="card-text">

<? 	$sql=$pdo->Query("SELECT id FROM db_video WHERE  iduser = '".intval($id)."' LIMIT 1");	
if($sql->RowCount() == 0){ ?>
Хотите иметь активный депозит на прокте? Запишите видео обзор о нашем проекте, разместите на своем канале YOUTUBE и получите активный депозит в размере от 200 до 500 рублей на усмотрение администрации! 
<div style="margin-bottom:10px;"></div>
<div class="alert-danger" style="padding: 20px;font-weight: 500;border-radius: 4px;border-color: #f9fafc !important;background-color: #ffffff !important;color: #383345 !important;margin: 20px 0px;padding-left: 80px;"><i class="fa fa-exclamation-circle" style="position: absolute;font-size: 40px;margin-left: -55px;margin-top: 8px;"></i> <b>Важно!</b> При добавлении видео на модерацию, у вас должен быть, как минимум один активный депозит от 200 рублей, иначе видео будет отклонено!</div>
<b style="font-weight: 500;color: #2f2f2f;padding: 10px 0px 10px;font-size: 15px;margin-bottom: 0.4rem;margin-top: 10px;">Отправить видео на модерацию:</b>
<br>
</div>
<?
if(isset($_POST[message])){
if(filter_var($_POST[message], FILTER_VALIDATE_URL)!=false){

$url=$_POST[message];
$db->query("INSERT INTO db_video (user, iduser, comment) VALUES(?s,?i,?s)", $wallet, $id, $url);		
echo "<center><div style='display: inline-block;font-size: 14px;color: rgb(255, 255, 255);z-index: 10;right: 20px;bottom: 20px;box-shadow: rgba(0, 0, 0, 0.2) 0px 0px 3px;border: 1px solid rgba(255, 255, 255, 0);line-height: 1.72857143;position: fixed;width: 300px;background: #000000c2;padding: 10px;border-radius: 4px;z-index: 99999999;font-family: 'Roboto', sans-serif;font-weight: 400;'>Видео отправлено на модерацию!</div></center>";
}else{
echo "<center><div style='display: inline-block;font-size: 14px;color: rgb(255, 255, 255);z-index: 10;right: 20px;bottom: 20px;box-shadow: rgba(0, 0, 0, 0.2) 0px 0px 3px;border: 1px solid rgba(255, 255, 255, 0);line-height: 1.72857143;position: fixed;width: 300px;background: #000000c2;padding: 10px;border-radius: 4px;z-index: 99999999;font-family: 'Roboto', sans-serif;font-weight: 400;'>Укажите корректную ссылку!</div></center>";

}
}
?>
<form method="post" action="">
<input placeholder="Ссылка на ваше видео" value="" style="style=&quot;padding-left: 1rem;border: 2px solid #e4e4e4;float: left;margin-bottom: 0px;&quot;;margin-top: 8px;padding: 10px;border: 2px solid #dddddd7a;border-radius: 4px;color: #2f2f2f;text-align: left;min-width: 100%;" name="message" type="text" class="form-control">
<input name="send" value="Отправить видео" type="submit" class="btn btn-success upgrade-to-pro" style="padding: 13px 30px;margin-top: 15px;border: none;font-size: 15px;font-family: 'Montserrat', sans-serif;font-weight: 500;background: #1ba7b6;margin-bottom: 2px;width: 200px;">
</form>

<div style="clear:both; margin-bottom:30px;"></div>

<? }else{ echo "<br><br><center><div style='color: #0e0e0f;font-family: 'Montserrat', sans-serif;font-weight: 500;font-size: 15px;'>Добавление видео обзора доступно участнику 1 раз! Вы уже добавляли видео!</div></center><br><br></div>";
}
?>




	

</div>
</div>
</div>