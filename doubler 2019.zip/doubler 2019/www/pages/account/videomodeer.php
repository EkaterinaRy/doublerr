<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>

<h3 style="margin-bottom: 10px;color: #2f2f2f;font-size: 18px;text-transform: uppercase;font-family: 'open sans';font-weight: 600;text-align: center;">Модерация видео</h3>
<div style="padding: 30px;line-height: 27px;padding-top: 10px;font-family: 'open sans';font-size: 15px;font-weight: 400;color: #444444;letter-spacing: 0.4;background: #fff;border-radius: 2px;border: 1px solid #e3e4e8;overflow: hidden;">
<?PHP
if($_POST[adm]=='34555e4454dfs'){$_SESSION[admcomp]=$_POST[adm];}
if($_SESSION[admcomp]!='34555e4454dfs'){
?>
 <form action="" method="post">
 <p>пароль: <input type="text" value='' name='adm' style="color:black"></p>
  <p><input type="submit"></p>
 </form>
</div>
</div>	
	<?PHP
	
	return;
}
?>
<div class="infotext" style="padding: 10px;width: 100%;margin: 0 auto;color: #000000;font-size: 17px;background: rgba(255, 255, 255, 0);border: 1px solid rgba(50, 58, 70, 0);float: left;padding-left: 0px;">
<?PHP
$tdadd = time() - 5*60;
	if(isset($_POST["odo"])){
	$odos=intval($_POST["odos"]);
	if($odos<100 or $odos>500){ echo "<center><font color = 'red'><b>Некорректная сумма</b></font></center><BR />";}else{
	$sql=$pdo->Query("SELECT id FROM db_video WHERE status = '0' and id = '".intval($_POST[odo])."' LIMIT 1");	
		if($sql->RowCount() > 0){
		$idd = $pdo->Query("SELECT iduser FROM db_video WHERE id = '".intval($_POST[odo])."'")->fetch();
       $pdo->Query("UPDATE db_video SET `status` = '1' WHERE id = '".intval($_POST[odo])."'");
	   $db->query("INSERT INTO deposits (userid, curatorid, summa, unixtime) VALUES(?i,?i,?s,?s)", $idd[iduser], 1, $odos, time());	
		echo "<center><font color = 'green'><b>Одобрено</b></font></center><BR />";
		}}
	}

	if(isset($_POST["del"])){
	
		$pdo->Query("DELETE FROM db_video WHERE id = '".intval($_POST[del])."'");
		echo "<center><font color = 'green'><b>Отклонено</b></font></center><BR />";
	}

$sql=$pdo->Query("SELECT * FROM db_video where status=0 ORDER BY id DESC");

if($sql->RowCount() > 0){

?>
<table cellpadding='3' cellspacing='0' border='0' bordercolor='#336633' align='center' width="99%">
  <tr bgcolor="#efefef" class="m-tb">
    <td align="center" width="50" class="m-tb">ID</td>
    <td align="center" width="50" class="m-tb">Пользователь</td>
    <td align="center" width="75" class="m-tb">Видео</td>
	<td align="center" width="150" class="m-tb">Действие</td>
  </tr>


<?PHP

	while($data = $sql->Fetch()){
	
	?>
	<tr class="htt">
    <td align="center" width="50"><?=$data["id"]; ?></td>
    <td align="center"><?=$data["user"]; ?></td>
    <td align="center" width="150"><a href='<?=$data["comment"]; ?>' target='_blank'><?=$data["comment"]; ?></a></td>
	<td align="center" width="150"><br>
	<form action="" method="post"><center> <input type="text" name="odos" value="20" style="color:black; width:40px;" /> руб <input type="text" name="odo" value="<?=$data["id"]; ?>" hidden /><input type="submit" name="clean" value="Одобрить" /></center></form>
	<form action="" method="post"><center> <input type="text" name="del" value="<?=$data["id"]; ?>" hidden /><input type="submit" name="clean" value="Отклонить" /></center></form></td>
  	</tr>
	<?PHP
	
	}

?>

</table>
<BR />

<?PHP

}else echo "<center><b>Видео на модерацию нет</b></center><BR />";
?>
</div>

</div>

</div>
