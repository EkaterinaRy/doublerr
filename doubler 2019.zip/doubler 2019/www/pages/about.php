<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>

<style>
.about__description {
    font-size: 15px;
    color: #252e43;
    line-height: 30px;
    font-weight: 400;
    margin-top: 15px;
    font-family: 'Montserrat', sans-serif;
    text-align: left;
    width: 100%;
    margin: 0 auto;
    margin-bottom: 40px;
}
</style>

<div class="about" style="margin: 0px;padding-top: 40px; box-shadow: none;">

<div class="container">
<h2 class="about__header" data-title="О нашем проекте">О нашем проекте
<?if(empty($id)){?>
<? } else { ?>
<a href="/account" style="border-radius: 70px;padding: 13px 25px;outline: none;z-index: 999999;background: #1ba7b6;color: #fff;font-size: 15px;font-family: 'Montserrat', sans-serif;font-weight: 500;box-shadow: 0 12px 20px -10px rgba(21, 148, 193, 0), 0 4px 20px 0px rgba(0, 0, 0, 0.12), 0 7px 8px -5px rgba(46, 47, 47, 0.18);border: none;margin-left: 20px;text-transform: none;margin-top: -2px;position: absolute;line-height: 20px;width: 240px;margin-left: 130px;" class="waves-effect waves-light">Вернуться в кабинет</a>
<?PHP } ?> 
</h2>
<h6 style="font-size: 14px;text-align: center;margin-bottom: 30px;letter-spacing: 2px;">Подробная информация о нашем проекте</h6>
<div class="about__description" style="box-shadow: 0px 5px 55px rgba(0, 0, 0, 0.09);background: #fff;border-radius: 10px;padding: 30px;">

<div class="row" style="margin: 0px 0px 10px;">	


<div style="text-align: left;">
Наша компания предлагает Вам долевое участие в высоко прибыльном бизнесе, основанном на трейдинге криптовалют.<br>
<div style="font-weight: 600;color: #2f2f2f;padding: 15px 0px 15px;">Почему деятельность, связанная с трейдингом криптовалют является прибыльной?</div>
О криптовалютах в наше время слышал каждый. Мир не стоит на месте, и цифровые валюты набирают популярность с каждым годом. Криптовалюте не страшна инфляция, и это является одним из ее преимуществ. Виды цифровой валюты нескончаемо множатся, что указывает на рост ее популярности. Стоимость биткоинов, как и других популярных цифровых валют, стремительно растет. 
Поэтому трейдинг является весьма прибыльным видом деятельности.<br>В нашей команде работают высококвалифицированные, профессиональные трейдеры и аналитики, накопившие огромный опыт и знания в данной сфере, поэтому, при использовании нашей платформы, все возможные риски минимальны.<p></p>

</div>
 
				
</div>

</div>
</div>

</div>