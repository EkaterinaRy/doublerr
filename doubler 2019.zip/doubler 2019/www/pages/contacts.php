<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>
<style>
.about__description {
    font-size: 15px;
    color: #252e43;
    line-height: 30px;
    font-weight: 400;
    margin-top: 15px;
    font-family: 'Montserrat', sans-serif;
    text-align: left;
    width: 100%;
    margin: 0 auto;
    margin-bottom: 60px;
}
</style>
<div class="about" style="margin: 0px;padding-top: 40px; box-shadow: none;">
<div class="container">
<h2 class="about__header" data-title="Помощь">Контакты
<?if(empty($id)){?>
<? } else { ?>
<a href="/account" style="border-radius: 70px;padding: 13px 25px;outline: none;z-index: 999999;background: #1ba7b6;color: #fff;font-size: 15px;font-family: 'Montserrat', sans-serif;font-weight: 500;box-shadow: 0 12px 20px -10px rgba(21, 148, 193, 0), 0 4px 20px 0px rgba(0, 0, 0, 0.12), 0 7px 8px -5px rgba(46, 47, 47, 0.18);border: none;margin-left: 20px;text-transform: none;margin-top: -2px;position: absolute;line-height: 20px;width: 240px;margin-left: 130px;" class="waves-effect waves-light">Вернуться в кабинет</a>
<?PHP } ?> 
</h2>
<h6 style="font-size: 14px;text-align: center;margin-bottom: 30px;letter-spacing: 2px;">Контактные данные для связи с техподдержкой</h6>
<div class="about__description" style="box-shadow: 0px 5px 55px rgba(0, 0, 0, 0.09);background: #fff;border-radius: 10px;padding: 30px;">
У вас возникла проблема при работе с проектом или же вы хотите задать дополнительный вопрос? Напишите нам в техническую поддержку и мы с радостью ответим вам.
При обращении, укажите в письме свой номер кошелька Payeer или AdvCash. 

<section class="section -map">
<div class="map_contacts">
            <div class="map_contacts--content">
     <div class="map_contacts--info">
                                <div>
                    <p class="info--payeer">СЛУЖБА ТЕХНИЧЕСКОЙ ПОДДЕРЖКИ</p>
                    <p class="info--address"><i class="fa fa-envelope" style="font-size: 15px;margin-right: 5px;"></i><a href="mailto:morrows.zone@yandex.ru" style="color: #2f2f2f;"> morrows.zone@yandex.ru</a> </p>
                </div>
                <div class="clear"></div>
                <div>
                    <p class="info--payeer">Мы в вконтакте</p>
                    <p class="info--address"><i class="fa fa-vk" style="font-size: 15px;margin-right: 5px;"></i><a href="https://vk.com/morrows_zone" target="_blank" style="color: #2f2f2f;"> https://vk.com/morrows_zone</a></p>
                </div>
                <div class="clear"></div>
                
                
                
              </div>

              
            </div>
          </div>
          <div id="map" style="overflow: hidden;">
		  <div style="height: 100%; width: 100%; position: absolute; background-color: rgb(229, 227, 223);">
		  <iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d4491.01807840931!2d37.627678!3d55.749659!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sru!2sru!4v1481206169170" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen=""></iframe>
		  </div></div>
      
    </section>

</div>
		
</div>

</div>





