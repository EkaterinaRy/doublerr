<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>
<div class="about">
<div style="padding: 60px 0px;">
<div class="container">
<div class="row">
<div class="col-md-offset-1 col-xs-6 text-right fsz-16 pt-15 xs-text" style="margin-left: 2%;width: 61%;">
<p class="index-a-text">В течение нескольких лет мы занимались трейдингом на биржах криптовалюты. Благодаря накопленному опыту нам удалось достичь высоких результатов. Именно так у нас возникла идея создания инвестиционной платформы. </p>
</div>
<div class="col-xs-5" style="padding-left: 70px;padding-top: 6px;width: 35%;">
<img src="/img/logo.png" alt="" style="position: absolute;width: 60px;margin-left: -65px;margin-top: 1px;">
<h2 class="section-title" style="padding-top: 5px;"> <span class="light-font"></span> <strong style="font-size: 27px;">MORROWS ZONE </strong> </h2>
<h4 class="sub-title">Немного о нас</h4>
</div>
</div>
</div>
</div>
<div class="container">
<h2 class="about__header" data-title="Инвестиционные предложения">Инвестиционные предложения</h2>
<h6 style="font-size: 14px;text-align: center;margin-bottom: 60px;letter-spacing: 2px;">Выбирайте для себя наиболее подходящий тарифный план</h6>
<div class="about__description">
<div class="row">
<a href="#tab1" style="display: block;">
<div class="col-xs-4 text-center">
<div class="product-box index-s-block">
<div class="product-media" style="height: 140px;">
<div style="position: absolute;margin-top: 30px;margin-left: 76px;z-index: 999;font-size: 25px;color: #ffffff;font-weight: 900;text-shadow: 0 8px 31px rgba(0, 0, 0, 0.14);">Minimum</div>
<div style="position: absolute;margin-top: 106px;margin-left: 105px;z-index: 999;font-size: 30px;color: #4a4a4b;font-weight: 700;text-shadow: 0 8px 31px rgba(0, 0, 0, 0.09);">150%</div>
<img class="shape" alt="" src="/img/shap-small.png">
</div>
<div class="product-caption">
<p><b>Полный срок</b><i>50 дней </i></p>
<p><b>Сумма</b><i>от 200 до 1999</i></p>
<p><b>Ежедневно</b><i>по 3%</i></p>
<p><b>Выплаты</b><i>автоматические</i></p>
<p><b>Валюта</b><i>RUB</i></p>
<div class="price">
</div>
</div>
</div>
</div>
</a>
<a href="#tab2" style="display: block;">
<div class="col-xs-4 text-center">
<div class="product-box index-s-block" style="box-shadow: 0px 5px 55px rgba(0, 0, 0, 0.26);">
<div class="product-media" style="height: 140px;">
<div style="position: absolute;margin-top: 30px;margin-left: 90px;z-index: 999;font-size: 25px;color: #ffffff;font-weight: 900;text-shadow: 0 8px 31px rgba(0, 0, 0, 0.14);">Normal</div>
<div style="position: absolute;margin-top: 106px;margin-left: 105px;z-index: 999;font-size: 30px;color: #4a4a4b;font-weight: 700;text-shadow: 0 8px 31px rgba(0, 0, 0, 0.09);">200%</div>
<img class="shape" alt="" src="/img/shap-small.png">
</div>
<div class="product-caption">
<p><b>Полный срок</b><i>50 дней </i></p>
<p><b>Сумма</b><i>от 2000 до 9999</i></p>
<p><b>Ежедневно</b><i>по 4%</i></p>
<p><b>Выплаты</b><i>автоматические</i></p>
<p><b>Валюта</b><i>RUB</i></p>
<div class="price">
</div>
</div>
</div>
</div>
</a>
<a href="#tab3" style="display: block;">
<div class="col-xs-4 text-center">
<div class="product-box index-s-block">
<div class="product-media" style="height: 140px;">
<div style="position: absolute;margin-top: 30px;margin-left: 73px;z-index: 999;font-size: 25px;color: #ffffff;font-weight: 900;text-shadow: 0 8px 31px rgba(0, 0, 0, 0.14);">Maximum</div>
<div style="position: absolute;margin-top: 106px;margin-left: 105px;z-index: 999;font-size: 30px;color: #4a4a4b;font-weight: 700;text-shadow: 0 8px 31px rgba(0, 0, 0, 0.09);">250%</div>
<img class="shape" alt="" src="/img/shap-small.png">
</div>
<div class="product-caption">
<p><b>Полный срок</b><i>50 дней </i></p>
<p><b>Сумма</b><i>от 10000 до 100000</i></p>
<p><b>Ежедневно</b><i>по 5%</i></p>
<p><b>Выплаты</b><i>автоматические</i></p>
<p><b>Валюта</b><i>RUB</i></p>
<div class="price">
</div>
</div>
</div>
</div>
</a>

</div>
</div>
		
</div>
<div class="container" style="padding: 0px 0px 80px !important;">
<h2 class="about__header" data-title="Преимущества платформы">Преимущества платформы</h2>
<h6 style="font-size: 14px;text-align: center;margin-bottom: 60px;letter-spacing: 2px;">Детальная информацио о наших преимуществах</h6>
<div class="container" style="text-align: center;">
          <div class="row">
            <div class="col-xs-4">
			<div class="leftp" style="margin-top: 40px;">
			<h1 class="lh1">Партнерская программа 7%</h1>
			<p class="lefp" style="padding-left: 20px;">Приглашайте партнеров, и получайте 7% от их пополнений, что позволит вам зарабатывать без вложений</p> 
			<img class="ileftp" src="/img/feat_1.svg">
			</div>
			<div class="leftp">
			<h1 class="lh1" style="padding-left: 20px;">Безопасность личных данных</h1>
			<p class="lefp">Наши технические специалисты следят за безопасностью ваших личных данных, ежедневно обновляя платформу</p> 
			<img class="ileftp" src="/img/feat_3.svg">
			</div>
            </div>
			<div class="col-xs-4">
				<div class="phone">
						<div class="wrapper">
							<span class="cap">Рассчитать прибыль</span>
							<div class="cfix">
								<input id="calc_amount" placeholder="Введите сумму" type="text" value="200">
							</div>
							<ul class="head cfix">
								<li>День</li>
								<li>За день</li>
								<li>Общий доход</li>
							</ul>
							<div class="scroll">
								<ul class="inner" id="calc_result"></ul>
							</div>
						</div>
					</div>
					<script>
					function calc(){jQuery('#calc_result').html('');
					percent = 3;
					profit = 0;
					amount = jQuery('#calc_amount').val();
					if (amount>1999) { percent = 4;}
					if (amount>9999) { percent = 5;}
					if (amount<200) {amount = 0; }
					for (var i = 1; i <= 50; i++) {profit = parseFloat(profit) + parseFloat(amount*percent/100);
					profitday = parseFloat(amount*percent/100);
					jQuery('#calc_result').append('<li class="cfix"><span>'+i+'<\/span><span>'+profitday.toFixed(2)+'<\/span><span>'+profit.toFixed(2)+'<\/span><\/li>');
					if (percent<3) percent += 0.3;}}
					jQuery(document).ready(function(){jQuery('#calc_amount').on('change keyup', function(){calc();});
					calc();})
					</script>
			</div>
						
						
			<div class="col-xs-4">
			<div class="rightp" style="margin-top: 40px;">
			<h1 class="rh1">Продуманный маркетинг</h1>
			<p class="rigp">Плавный, продуманный маркетинг дает нам перспективы на долгое сотрудничество с нашими инвесторами</p> 
			<img class="irightp" src="/img/feat_5.svg"></div>
			<div class="rightp">
			<h1 class="rh1">Техническая поддержка 24/7</h1>
			<p class="rigp">Наша техподдержка оказывает эффективную помощь в решении любых интересующих вас вопросов.</p> 
			<img class="irightp" src="/img/feat_2.svg">
			</div>
            </div>
			</div>
        </div>
</div>
</div> 