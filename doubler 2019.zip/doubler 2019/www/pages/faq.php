<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>
<style>
.about__description {
    font-size: 15px;
    color: #252e43;
    line-height: 30px;
    font-weight: 400;
    margin-top: 15px;
    font-family: 'Montserrat', sans-serif;
    text-align: left;
    width: 100%;
    margin: 0 auto;
    margin-bottom: 40px;
}

</style>
<div class="about" style="margin: 0px;padding-top: 40px; box-shadow: none;">

<div class="container">
<h2 class="about__header" data-title="Вопрос - Ответ">Вопрос - Ответ
<?if(empty($id)){?>
<? } else { ?>
<a href="/account" style="border-radius: 70px;padding: 13px 25px;outline: none;z-index: 999999;background: #1ba7b6;color: #fff;font-size: 15px;font-family: 'Montserrat', sans-serif;font-weight: 500;box-shadow: 0 12px 20px -10px rgba(21, 148, 193, 0), 0 4px 20px 0px rgba(0, 0, 0, 0.12), 0 7px 8px -5px rgba(46, 47, 47, 0.18);border: none;margin-left: 20px;text-transform: none;margin-top: -2px;position: absolute;line-height: 20px;width: 240px;margin-left: 130px;" class="waves-effect waves-light">Вернуться в кабинет</a>
<?PHP } ?> 
</h2>
<h6 style="font-size: 14px;text-align: center;margin-bottom: 30px;letter-spacing: 2px;">Ответы на часто задаваемые вопросы</h6>
<div class="about__description" style="box-shadow: 0px 5px 55px rgba(0, 0, 0, 0.09);background: #fff;border-radius: 10px;padding: 30px;">
<div class="faq_list">
				<div class="faq_block" style="margin-bottom: 20px;">
					<div style="font-weight:600; color: #2f2f2f;">1) Что такое MORROWS ZONE?</div>
					<div class="answer">Это уникальная, безопасная, инвестиционная онлайн платформа. Команда Morrows Zone, состоит из опытных трейдеров, которые в свою очередь могут обеспечить стабильный доход нашим инвесторам!
</div>
				</div>
				<div class="faq_block" style="margin-bottom: 20px;">
					<div style="font-weight:600; color: #2f2f2f;">2) Кто может инвестировать в MORROWS ZONE?</div>
					<div class="answer">Инвестировать в MORROWS ZONE может любой желающий достигший 18 летнего возвраста, в остальном никаких ограничений нет.</div>
				</div>
				<div class="faq_block" style="margin-bottom: 20px;">
					<div style="font-weight:600; color: #2f2f2f;">3) Какие инвестиционные планы вы предлагаете?</div>
					<div class="answer">Мы предлагаем инвестировать средства и получать до 5% ежедневно, ваш доход зависит от суммы инвестиций. Срок депозитов по всем 3-м тарифам составляет 50 дней. Более детально ознакомиться с тарифами можно на главной странице!</div>
				</div>
				<div class="faq_block" style="margin-bottom: 20px;">
					<div style="font-weight:600; color: #2f2f2f;">4) Валюта сайта и с какой платежной системой работаете?</div>
					<div class="answer">На данный момент наша платформа работает с платежными системами Payeer и AdvCash. Валюта платформы - RUB. Список платежных систем может корректироваться администрацией проекта!</div>
				</div>
				<div class="faq_block" style="margin-bottom: 20px;">
					<div style="font-weight:600; color: #2f2f2f;">5) Как сделать мой первый депозит?</div>
					<div class="answer">Для создания депозита вам необходимо пройти несложную процедуру авторизации в системе, используя кошелек Payeer (P*******) или AdvCash (*****@mail.ru), далее ввести сумму депозита в форму и нажать кнопку оплатить, после оплаты ваш депозит автоматически будет в работе!</div>
				</div>
				<div class="faq_block" style="margin-bottom: 20px;">
					<div style="font-weight:600; color: #2f2f2f;">6) Какая минимальная и максимальная сумма депозита?</div>
					<div class="answer">Минимальная сумма депозита - 200 рублей, максимальная в свою очередь не может превышать 100000 рублей за один вклад. В системе разрешено иметь один или более депозитов!</div>
				</div>
				<div class="faq_block" style="margin-bottom: 20px;">
					<div style="font-weight:600; color: #2f2f2f;">7) Что нужно сделать, чтобы получить выплату?</div>
					<div class="answer">Выплаты на проекте автоматические и не требуют входа в аккаунт. Денежные средства поступают на кошелек, который вы использовали при регистрации / авторизации на проекте. </div>
				</div>
				
				<div class="faq_block" style="margin-bottom: 20px;">
					<div style="font-weight:600; color: #2f2f2f;">9) Есть ли у вас партнерская программа?</div>
					<div class="answer">Да, у нас присутствует партнерская программа. Доход по партнерской программе составляет <b style="font-weight:600; color: #2f2f2f;">7%</b>, выплаты поступают моментально на ваш кошелек, указанный при регистрации / авторизации!</div>
				</div>
				<div class="faq_block" style="margin-bottom: 20px;">
					<div style="font-weight:600; color: #2f2f2f;">10) Как я могу с Вами связаться</div>
					<div class="answer">Если у Вас возникли дополнительные вопросы - перейдите в раздел "Контакты" и свяжитесь с нами по указанным реквизитам, либо используйте онлайн консультант для более быстрого ответа!</div>
				</div>
				
				
			</div>
</div>
		
</div>

</div>