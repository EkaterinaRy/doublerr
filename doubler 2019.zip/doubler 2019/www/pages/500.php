
<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>

<p style="text-align: center;padding: 30px;line-height: 1.42857143;padding-top: 10px;font-family: 'open sans';font-size: 15px;font-weight: 400;color: #444444;letter-spacing: 0.4;line-height: 25px;background: #fff;border-radius: 2px;border: 1px solid #e3e4e8;">
 <br>
<strong><span class="style1"><b>Internal Server Error, внутренняя ошибка сервера! </b></span></strong><br>
</div>
