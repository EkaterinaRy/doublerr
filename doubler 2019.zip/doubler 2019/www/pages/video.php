<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>
<style>
.about__description {
    font-size: 15px;
    color: #252e43;
    line-height: 30px;
    font-weight: 400;
    margin-top: 15px;
    font-family: 'Montserrat', sans-serif;
    text-align: left;
    width: 100%;
    margin: 0 auto;
    margin-bottom: 40px;
}
</style>

<div class="about" style="margin: 0px;padding-top: 40px; box-shadow: none;">
<div class="container">
<h2 class="about__header" data-title="Видео обзоры">Видео обзоры
<?if(empty($id)){?>
<? } else { ?>
<a href="/account" style="border-radius: 70px;padding: 13px 25px;outline: none;z-index: 999999;background: #1ba7b6;color: #fff;font-size: 15px;font-family: 'Montserrat', sans-serif;font-weight: 500;box-shadow: 0 12px 20px -10px rgba(21, 148, 193, 0), 0 4px 20px 0px rgba(0, 0, 0, 0.12), 0 7px 8px -5px rgba(46, 47, 47, 0.18);border: none;margin-left: 20px;text-transform: none;margin-top: -2px;position: absolute;line-height: 20px;width: 240px;margin-left: 130px;" class="waves-effect waves-light">Вернуться в кабинет</a>
<?PHP } ?> 
</h2>
<h6 style="font-size: 14px;text-align: center;margin-bottom: 30px;letter-spacing: 2px;">Видео обзоры от участников проекта!</h6>
</div>
<div class="container">
<div class="about__description" style="margin-top: 30px;">
<div class="row" style="margin: 0px 0px;">
<?PHP
// количество записей, выводимых на странице
$per_page=6;
// получаем номер страницы
if (isset($_GET['page'])) $page=($_GET['page']-1); else $page=0;
// вычисляем первый оператор для LIMIT
$start=abs($page*$per_page);
// составляем запрос и выводим записи
// переменную $start используем, как нумератор записей.
$col=$db->getOne("SELECT count(*) FROM `db_video` where status=1");
if($col>0){
$depositsrow=$db->query("SELECT * FROM db_video where status=1 ORDER BY id DESC limit 6 ");
while($news=$db->fetch($depositsrow)){
		if( strripos($news[comment], 'watch'))
		{
			$pieces = explode("=",$news[comment]);
             $pieces1 = explode("&",$pieces[1]);
		$news[comment]='https://www.youtube.com/embed/'.$pieces1[0];
		}
	
	?>	
<div class="col-xs-4 text-center" style="margin-bottom: 20px;">	
<div style="box-shadow: 0px 5px 55px rgba(0, 0, 0, 0.09);background: #fff;border-radius: 10px;padding: 20px;">
  <div style="margin-bottom: 10px;font-weight: 500;color: #2f2f2f;font-size: 14px;text-align: center;">Видео от участника:  ** <?=$news[user]=substr($news[user], 2, -3)?> ***</div>
<iframe style="margin:0 0 10px 0px;" src="<?=$news[comment]?>" allowfullscreen="" width="100%" height="220px" frameborder="0" ></iframe>
</div>
</div>
<?PHP
}
}else echo "<center style='padding: 40px;padding-bottom: 140px;'><font style='color: #363636;font-size: 30px;'> Видео обзоров нет! </font></center>";
?> 
				
</div>
</div>	
</div>
</div>