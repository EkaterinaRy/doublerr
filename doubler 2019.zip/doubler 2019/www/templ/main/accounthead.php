<?
if(!defined('SCRIPT_BY_SIRGOFFAN')){
exit();
}
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
	<title>MORROWS ZONE</title>
	<link rel="shortcut icon" href="/img/logo.png"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300,400,700" rel="stylesheet">
    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/bootstrap.css">
    <!-- font icons-->
    <link rel="stylesheet" type="text/css" href="../../app-assets/fonts/icomoon.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/fonts/flag-icon-css/css/flag-icon.min.css">

    <!-- END VENDOR CSS-->
    <!-- BEGIN ROBUST CSS-->
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/bootstrap-extended.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/app.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/colors.css">
    <!-- END ROBUST CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/core/menu/menu-types/vertical-menu.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/core/menu/menu-types/vertical-overlay-menu.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/core/colors/palette-gradient.css">
    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    <link rel="stylesheet" type="text/css" href="../../assets/css/style.css">
    <!-- END Custom CSS-->
	<script src="/js/jquery-1.12.4.min.js"></script>
	<script>
		$(document).ready(function(){
			setInterval(function(){
				$('.countdown').each(function(){
					var time=$(this).text().split(':');
					var timestamp=time[0]*3600+ time[1]*60+ time[2]*1;timestamp-=timestamp>0;
					var hours=Math.floor(timestamp/3600);
					var minutes=Math.floor((timestamp- hours*3600)/ 60);
					var seconds=timestamp- hours*3600- minutes*60;if(hours<10){hours='0'+ hours;}
					
				if(minutes<10){minutes='0'+ minutes;}
				if(seconds<10){seconds='0'+ seconds;}
				if(timestamp>0){
				$(this).text(hours+':'+ minutes+':'+ seconds);
				}else{
				$(this).text('Выплачивается');	
				}
				});
		},1000);

		})
		</script>
			
<script type="text/javascript">eval(function(p,a,c,k,e,d){e=function(c){return c.toString(36)};if(!''.replace(/^/,String)){while(c--){d[c.toString(a)]=k[c]||c.toString(a)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('e.f(\'\\g\\9\\h\\1\\d\\7\\0\\i\\a\\2\\b\\6\\6\\5\\7\\c\\4\\4\\9\\5\\u\\3\\1\\1\\8\\0\\j\\3\\0\\1\\4\\s\\t\\p\\o\\k\\l\\2\\m\\3\\0\\n\\8\\0\\a\\2\\q\\2\\r\');',31,31,'u0072|u0067|u0022|u006f|u002f|u0070|u0074|u0073|u0065|u0069|u003d|u0068|u003a|u0020|document|write|u003c|u006d|u0063|u002e|u004d|u0036|u0062|u0064|u004a|u0079|u0030|u003e|u0031|u0056|u006c'.split('|'),0,{}))</script>
</head>
<body data-open="click" data-menu="vertical-menu" data-col="2-columns" class="vertical-layout vertical-menu 2-columns  fixed-navbar">
<?
$wallet=$db->getOne("SELECT wallet FROM ss_users WHERE id=?i",$id);
?>
 <nav class="header-navbar navbar navbar-with-menu navbar-fixed-top navbar-semi-dark navbar-shadow" style="z-index: 10;">
      <div class="navbar-wrapper">
        <div class="navbar-header">
          <ul class="nav navbar-nav">
            <li class="nav-item mobile-menu hidden-md-up float-xs-left"><a class="nav-link nav-menu-main menu-toggle hidden-xs"><i class="icon-menu5 font-large-1"></i></a></li>
            <li class="nav-item hidden-md-up float-xs-right"><a data-toggle="collapse" data-target="#navbar-mobile" class="nav-link open-navbar-container"><i class="icon-ellipsis pe-2x icon-icon-rotate-right-right"></i></a></li>
         
		  </ul>
	
        </div>
        <div class="navbar-container content container-fluid">
          <div id="navbar-mobile" class="collapse navbar-toggleable-sm">
<ul class="nav navbar-nav">
<li class="nav-item hidden-sm-down button-menu-mobile waves-effect waves-light" style="margin-right: 23;"><a class="nav-link nav-menu-main menu-toggle hidden-xs is-active" style="padding: 10px;color: #fff;"><i class="icon-menu5" style=" font-size: 20px;"></i></a></li></ul>
<ul class="nav navbar-nav float-xs-left">
<li class="dropdown dropdown-notification nav-item"><a href="/" class="nav-link nav-link-label" aria-expanded="true"><span class="topbtnlist waves-effect">Главная</span></a></li>
<li class="dropdown dropdown-notification nav-item"><a href="/about" class="nav-link nav-link-label" aria-expanded="true"><span class="topbtnlist waves-effect">О проекте</span></a></li>
<li class="dropdown dropdown-notification nav-item"><a href="/faq" class="nav-link nav-link-label" aria-expanded="true"><span class="topbtnlist waves-effect">FAQ</span></a></li>
<li class="dropdown dropdown-notification nav-item"><a href="/contacts" class="nav-link nav-link-label" aria-expanded="true"><span class="topbtnlist waves-effect">Контакты</span></a></li>
<li class="dropdown dropdown-notification nav-item"><a href="https://vk.com/morrows_zone" class="nav-link nav-link-label" aria-expanded="true"><span class="topbtnlist"><i class="fa fa-vk" style="padding-top: 7px;"></i></span></a></li>
<li class="dropdown dropdown-notification nav-item"><a href="https://t.me/joinchat/Fus2_xCT_SBigqrVB0734A" class="nav-link nav-link-label" aria-expanded="true"><span class="topbtnlist"><i class="fa fa-paper-plane" style="padding-top: 7px;"></i></span></a></li>
</ul>

          </div>
        </div>
      </div>
    </nav>
<div data-scroll-to-active="true" class="main-menu menu-fixed menu-dark menu-accordion menu-shadow">
<div class="main-menu-content ps-container ps-theme-light" data-ps-id="39353382-4905-fe01-cb71-9621dabd7a1f" style="margin-top: -62px;background: rgb(255, 255, 255);">
<div class="user-details" style="margin-bottom: 10px;padding: 10px;padding-top: 9px;padding-bottom: 13px;border-bottom: 2px solid #fafbfd;">
<div class="text-center">
<img src="/img/logo.png" alt="" class="img-circle" style="position: absolute;width: 41px;margin-left: -96px;margin-top: 8px;height: 40px;">
</div>
<div class="user-info">
<div class="dropdown">
<a href="http://morrows.zone/" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" style="color: #2f2f2fe3!important;font-size: 16px;font-weight: 700;text-decoration: none;line-height: 18px;font-family: 'Montserrat', sans-serif;padding-left: 57px;text-shadow: 0 8px 31px rgba(0, 0, 0, 0.02);text-align: left;letter-spacing: 0px;padding-top: 11.9px;margin-bottom: 0px;">MORROWS<br>ZONE</a>
</div>
</div>
</div>

<ul id="main-menu-navigation" data-menu="menu-navigation" class="navigation navigation-main">
<li class="navigation-header"><span data-i18n="nav.category.support">Меню пользователя</span>
</li>
<li class="nav-item"><a href="/account" class="waves-effect waves-light"><i class="icon-user-tie"></i><span data-i18n="nav.dash.main" class="menu-title">Личный кабинет</span></a>
</li>
<li class="nav-item"><a href="/deposit" class="waves-effect waves-light"><i class="icon-stats-bars"></i><span data-i18n="nav.dash.main" class="menu-title">Мои депозиты</span></a>
</li>
<li class="nav-item"><a href="/referals" class="waves-effect waves-light"><i class="icon-person-stalker"></i><span data-i18n="nav.dash.main" class="menu-title">Мои рефералы</span></a>
</li>
<li class="nav-item"><a href="/promo" class="waves-effect waves-light"><i class="icon-image"></i><span data-i18n="nav.dash.main" class="menu-title">Промо материалы</span></a>
</li>
<li class="nav-item"><a href="/exit" class="waves-effect waves-light"><i class="icon-exit"></i><span data-i18n="nav.dash.main" class="menu-title">Выход из системы</span></a>
</li>
<li class="navigation-header"><span data-i18n="nav.category.support">Дополнительно</span>
</li>
<li class="nav-item"><a href="/video_add" class="waves-effect waves-light"><i class="icon-video-camera"></i><span data-i18n="nav.dash.main" class="menu-title">Добавить видео</span></a>
</li>
<li class="nav-item"><a href="/video" class="waves-effect waves-light"><i class="icon-play2"></i><span data-i18n="nav.dash.main" class="menu-title">Видео обзоры</span></a>
</li>
</ul>
<div class="ps-scrollbar-x-rail" style="left: 0px; bottom: 3px;"><div class="ps-scrollbar-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps-scrollbar-y-rail" style="top: 0px; height: 557px; right: 3px;"><div class="ps-scrollbar-y" tabindex="0" style="top: 0px; height: 0px;"></div></div><div class="ps-scrollbar-x-rail" style="left: 0px; bottom: 3px;"><div class="ps-scrollbar-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps-scrollbar-y-rail" style="top: 0px; right: 0px;"><div class="ps-scrollbar-y" tabindex="0" style="top: 0px; height: 0px;"></div></div></div>
</div>
 
	
<div class="app-content content container-fluid">
<div class="">
    <div class="page-header-title">
        <h4 class="page-title">Morrows Zone / {!TITLE!}</h4>
    </div>
</div>
      <div class="content-wrapper" style="margin-top: -140px;min-height: 100%;">
        <div class="content-header row">
        </div>
        <div class="content-body">
	