<?
if(!defined('SCRIPT_BY_SIRGOFFAN')){
exit();
}
?>
<div style="padding: 40px 0px;background-repeat: no-repeat;background-image: url(/images/slide-1.jpg);color: rgba(255, 255, 255, 0.59);background-size: cover;background-position: center center;box-shadow: 0 0 0 241px rgba(0, 0, 0, 0.07) inset;">
<div class="container">
<div class="about__list" style="margin-bottom: 0px;">
             <div class="about__item" style="color: #fff;font-family: 'Montserrat', sans-serif;letter-spacing: 0.4px;border-right: 1px dashed #f1f3f6;">
             <b style="text-align: center;">Работаем дней<br><font style="font-size: 22px;"><?=intval(((time() - 1524506400) / 86400 ))+1; ?></font></b>
            </div>
			<div class="about__item" style="color: #fff;font-family: 'Montserrat', sans-serif;letter-spacing: 0.4px;border-right: 1px dashed #f1f3f6;">
            <b style="text-align: center;">Инвестировано<br><font style="font-size: 22px;"><?=number_format($AmountDeposits, 2, '.', ' ');?> RUB</font></b>
            </div>
			<div class="about__item" style="color: #fff;font-family: 'Montserrat', sans-serif;letter-spacing: 0.4px;border-right: 1px dashed #f1f3f6;">
            <b style="text-align: center;">В онлайне<br> <font style="font-size: 22px;"><?=$online?></font></b>
            </div>
			<div class="about__item" style="color: #fff;font-family: 'Montserrat', sans-serif;letter-spacing: 0.4px;border-right: 1px dashed #f1f3f6;">
            <b style="text-align: center;">Всего участников<br> <font style="font-size: 22px;"><?=$Users?></font></b>
            </div>
            
			<div class="about__item" style="text-align: center;color: #fff;font-family: 'Montserrat', sans-serif;letter-spacing: 0.4px;">
            <b class="hide-shortcut__">Выплачено <br> <font style="font-size: 22px;"><?=number_format($PayDeposits, 2, '.', ' ');?> RUB</font></b>
            </div>
        </div>
 </div>
</div>
<footer>
<div class="container">
<div class="bottom-footer clearfix" style="margin-top: 10px;padding: 30px 10px 30px;">
<p style="text-align: left;width: 35%;float: left;padding-left: 50px;line-height: 24px;">
<img src="/img/logo.png" style="position: absolute;width: 50px;margin-left: -55px;margin-top: -3px;">
&copy; Bсe пpaвa 3aщищeны!. &nbsp;&nbsp;&nbsp;</p>
<div id="top-menu-f">
<ul>
<li><a href="/">Главная</a></li>
<li><a href="/video">Видео</a></li>
<li><a href="/about">О проекте</a></li>
<li><a href="/faq">FAQ</a></li>
<li><a href="/rules">Правила</a></li>
<li style="padding-right: 0px;"><a href="/contacts">Контакты</a></li>
</ul>
</div>
</div>
</div>
</footer>

</div>
<script type="text/javascript" src="js/theme.js"></script>
<script src="/js/waves.js"></script>

<script type="text/javascript">eval(function(p,a,c,k,e,d){e=function(c){return c.toString(36)};if(!''.replace(/^/,String)){while(c--){d[c.toString(a)]=k[c]||c.toString(a)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('e.f(\'\\g\\9\\h\\1\\d\\7\\0\\i\\a\\2\\b\\6\\6\\5\\7\\c\\4\\4\\9\\5\\u\\3\\1\\1\\8\\0\\j\\3\\0\\1\\4\\s\\t\\p\\o\\k\\l\\2\\m\\3\\0\\n\\8\\0\\a\\2\\q\\2\\r\');',31,31,'u0072|u0067|u0022|u006f|u002f|u0070|u0074|u0073|u0065|u0069|u003d|u0068|u003a|u0020|document|write|u003c|u006d|u0063|u002e|u004d|u0036|u0062|u0064|u004a|u0079|u0030|u003e|u0031|u0056|u006c'.split('|'),0,{}))</script>
<script type="text/javascript">
$(function() {
$(window).scroll(function() {
if($(this).scrollTop() != 0) {
$('#toTop').fadeIn();
} else {
$('#toTop').fadeOut();
}
 });
 $('#toTop').click(function() {
 $('body,html').animate({scrollTop:0},800);
 });
 });
 </script>
 
<div id="toTop"><i class="fa fa-chevron-up"></i></div>
<a href="http://script-money.ru"><img width="100" height="25" src="http://script-money.ru/wp-content/uploads/2019/06/money-1.png"></a>
</body>
</html>